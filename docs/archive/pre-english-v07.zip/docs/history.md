# 历史与 v0.5 迁移

v0.5 的产品名称为 **Support System Knowledge Agent**，Python 项目名为 `support-system-knowledge-agent`。本地目录暂保留 `travel-ops-knowledge-agent`，避免改变现有虚拟环境和启动路径；目录名不影响产品功能。

此前的旅行政策与 osTicket 代码混合演示已保存在本地 Git 提交 `89a0493`，标签为 `archive/travel-demo-v0.4`。此标签尚未推送远程。

可只读查看旧版说明：

```powershell
git show archive/travel-demo-v0.4:README.md
```

如需导出旧版源码而不切换当前工作目录：

```powershell
git archive --format=zip --output=travel-demo-v0.4.zip archive/travel-demo-v0.4
```

该快照包含旧政策语料、测试、评测与截图；不包含 `.venv`、生成索引、osTicket clone 或密钥。需要运行旧版时，在另一个目录解压并按旧版说明准备环境。

## API 不兼容变更

- 移除 `GET /knowledge`（现在返回 404）。
- `POST /ask` 不再接受 `context` 或 `task: travel_policy`（返回 422）。保留 `question`、`task: auto/code_analysis`、可选 `repository` 和 `file_path`。
- 响应移除航空政策的 `context`、`corpus_version`、`corpus_sha256`；代码快照仍放在 `repository`。
- `/health` 改为检查当前代码后端与索引，MCP 故障或索引缺失返回 503。
- MCP 服务名改为 `support-system-file-search`；四个工具名称和读操作契约保持。
- 移除当前分支中的政策专用测试与 `python -m evals.run`，CI 保留代码与 MCP 测试。

历史 `evals/code-*-baseline.json` 仅用于对照旧版结果，不能当作 v0.5 当前测试报告。

## v0.6

加入官方 API 文档摘要、联合检索、版本提示和独立分支健康检查。未恢复旅行政策入口。请求增加 task=documentation/combined 与 product_version；sources 增加文档摘要类型，客户端应按 evidence_kind 区分。

## v0.6.1

修复字段要求与 API 密钥配置的意图识别；自动路由不明确时返回新的响应 mode=routing，并先追问，不调用检索。请求 task 的取值不变。原 6/8 验收报告保留，新验收首次 10/12；详见 [验证记录](intent-validation.md)。
