# v0.6.1 意图识别修复与验证

## 本次修复

`app/intent.py` 将匹配用的大小写/全角归一化、字段要求与密钥配置规则集中到一处。路由与文档主题识别复用这些规则，不改写用户原问题、代码检索参数或证据原文。

已有的两个失败现已修复：“最少传哪些信息”命中必填字段摘要；“API 钥匙从哪个管理页面添加”进入密钥配置文档。源码关键词、文件路径、函数标识符和错误码仍可进入代码分支；英文 source IP 不再因为 source 单词误判为代码请求。显式 task 保留优先级。

自动模式缺少明确意图时返回 `needs_clarification` / `ambiguous_intent`，使用新增响应模式 `routing`。测试用断言阻止两路工具调用，验证这类问题不会为了找到内容而盲搜。前端显示“等待明确检索方向”；用户需补全问题重新提交，没有会话记忆。

## 可比较的修复前后结果

| 同一组开发问题 | 修复前 v0.6.0 | 修复后 v0.6.1 |
|---|---:|---:|
| 18 条开发回归（含已公开的两条失败） | 16/18 | 18/18 |

修复前：`evals/docs-v061-before-local.json`；修复后：`evals/docs-v061-local-baseline.json`，MCP 对照为 `evals/docs-v061-mcp-baseline.json`。三者 cases_sha256 相同。单元/集成测试 107 项通过；既有真实代码回归和后端一致性仍为 20/20。测试保留一条 Starlette TestClient/httpx 弃用提示。

## 新验收结果

旧 `evals/docs-acceptance-first.json` 保持原样（6/8）。新题在实现前冻结于 `docs_acceptance_v2_cases.json`，哈希和旧报告哈希写入 `docs_acceptance_v2_protocol.md`。

新验收首次结果为 10/12，记录在 `docs-acceptance-v2-first.json`。两条失败分别暴露“建单”的领域词缺口，以及“最低需要哪些输入”的句式覆盖缺口。分别返回证据不足和追问，均没有误给代码引用。发现后未针对新题继续修改规则。

开发集已经用来修复，不是未见问题测试；新验收也由同一助手编写，不能称为独立、盲测或全面语义评估。两个验收集不是同一批问题，6/8 与 10/12 不能当作受控的提升比例。

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m evals.run_support --suite dev --backend local
.\.venv\Scripts\python.exe -m evals.run_support --suite dev --backend mcp_stdio
```

首轮验收报告采用排他创建，已有报告时拒绝覆盖。今后若处理新失败，应先将它们转为开发回归，再建立新验收集。
