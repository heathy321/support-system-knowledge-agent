# 主代理与代码分析子代理

v0.6 在客服系统支持场景中增加官方文档分支。演示仓库只有 osTicket/osTicket，主代理名为「客服系统支持代理」，子代理名为「代码分析器」。

```mermaid
flowchart TD
    U[问题与可选文件路径] --> M[客服系统支持代理：范围检查]
    M --> D[官方文档摘要检索]
    D --> R
    M -->|CodeAnalysisTask| A[代码分析器]
    A --> T[四个只读 MCP 工具]
    T --> I[固定提交的本地代码索引]
    I --> T
    T --> V[快照、结构与引用校验]
    V --> A
    A --> R[状态 / 原文引用 / 调用记录]
    R --> M
```

## Agent 的实际实现

这是确定性编排，不是由大模型自主规划。主代理检查范围，构造独立 `CodeAnalysisTask(question, repository, file_path)`，真正调用子代理，再合并调用记录和请求元数据。子代理按问题选择结构概览、指定文件或标识符/主题词检索流程。

中文概念映射到有限的代码词表；显式函数名、错误码优先。它不会理解任意自然语言或生成未经证实的调用链。调用目标仓库代码、修改文件、访问其他仓库都不属于工具能力。

Web 默认通过 MCP stdio；`local` 后端共享检索实现用于对照。协议和工具边界见 [MCP 文档](file-search-mcp.md)。

## 请求与输出

`POST /ask` 至少需要 `question`。可选 `task` 为 `auto`、`documentation`、`code_analysis` 或 `combined`。自动路由基于有限关键词；代码分支仍使用独立任务接口。可提供仓库相对路径 `file_path`。`repository` 只接受配置中的 osTicket URL。

```json
{"question": "查看这个文件的入口", "file_path": "scp/login.php"}
```

代码分支使用 `static_code_analysis` 模式；文档和联合输出模式为 `documentation`、`combined`；自动路由不确定时为 `routing`，先追问而不调用工具。四种状态分别表示有证据、缺少目标、证据不足、上游失败。引用固定到提交与行号；`claims[].citation_ids` 关联实际片段。`context_kind` 描述声明体是否完整，不能用来推断根因。追问不保存服务端会话，需要用户补全问题重新提交。

旅行政策问题在主代理返回 `outside_project_scope`；旅行与代码混合的问题返回 `mixed_scope` 并要求单独提交代码问题。不会为此调用 MCP。官方 API 文档摘要已接入，详见 [文档检索](documentation.md)。

## 索引来源

固定提交由 `knowledge/repositories.json` 管理。`scripts/index_repository.py` 从 Git 对象读取该提交的原文，而非工作区文件。索引构建、Git 下载与应用查询分开；不执行 PHP，不运行仓库安装脚本。

只收录预算内的指定文本类型，排除部分第三方目录与大文件。文件未命中时只说「未包含在索引中」。主程序不会自动修改固定提交或重新下载仓库。
