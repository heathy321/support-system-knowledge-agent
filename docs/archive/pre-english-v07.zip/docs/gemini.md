# Gemini 可选接入：v0.7.0

已实现 Gemini Developer API 的实际 HTTP 适配器，并用模拟响应验证请求、错误处理与引用约束。**没有进行真实模型调用；账号权限、模型实际兼容性、回答质量、线上延迟和费用均未验证。**

默认仍使用离线证据整理。路由和 MCP 工具编排保持确定性；Gemini 只在检索成功后组织答案，不自主选择或调用工具。接入生成层构成检索增强生成流程，但不能把离线回归成绩当成 LLM 的正确率。

## 不花钱的验证

本次本地结果：146 项测试通过（含 39 项 Gemini/模拟/CLI 检查），MCP 支持问答回归 18/18，代码回归及后端一致性 20/20，三个 dry-run 案例通过，真实模型请求为 0。保留一条既有 Starlette TestClient/httpx 弃用提示。

在项目目录运行：

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m scripts.try_gemini
.\.venv\Scripts\python.exe -m evals.run_gemini --limit 3
```

后两项默认是 dry run：执行离线检索、构建请求并检查字符预算，不读取模型密钥，不连接 Google，不生成虚构模型答案。三个案例覆盖文档、代码和联合检索，后两者需要本地索引。可添加 `--backend mcp_stdio` 验证 MCP 链路；CLI 默认 `local`，Web 默认 MCP。

模拟测试使用 `httpx.MockTransport`，并禁止真实 HTTP transport，覆盖成功响应、无效引用、格式错误、模型拒答、输出截断、超时、限流、认证/上游错误、重定向拒绝和大小限制。它们不验证模型理解能力、提示注入抵抗能力或声明与证据的语义蕴含。

## 招聘方以后如何接入

默认模型 `gemini-3.5-flash-lite`，可通过 `GEMINI_MODEL` 修改。2026-10-28 核对的 [官方模型页](https://ai.google.dev/gemini-api/docs/models/gemini-3.5-flash-lite) 将它定位为低成本模型，支持结构化输出；[生命周期说明](https://ai.google.dev/gemini-api/docs/deprecations) 推荐新项目使用该系列。费用及可用配额以 [官方价格页](https://ai.google.dev/gemini-api/docs/pricing) 和测试者账号为准，不承诺免费额度。

以下步骤由测试者自行执行。`.env.example` 只是模板，项目不会自动加载 `.env`。密钥不提交 Git、不输入网页。

```powershell
$env:ENABLE_GEMINI = '1'
$env:GEMINI_MODEL = 'gemini-3.5-flash-lite'
$env:GEMINI_MAX_OUTPUT_TOKENS = '1024'
$env:GEMINI_TIMEOUT_SECONDS = '20'
# 隐藏输入，避免密钥文字出现在命令历史里。
$geminiSecret = Read-Host 'Gemini API key' -AsSecureString
$geminiPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($geminiSecret)
try { $env:GEMINI_API_KEY = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($geminiPointer) }
finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($geminiPointer)
    $geminiSecret.Dispose()
    Remove-Variable geminiSecret, geminiPointer
}
```

先运行 dry run；准备接受可能的费用时，再显式运行：

```powershell
# 最多一次模型请求，不自动重试。
.\.venv\Scripts\python.exe -m scripts.try_gemini --live
# 可选：上限 1～3 个请求；遇到首个失败即停止。
.\.venv\Scripts\python.exe -m evals.run_gemini --live --limit 1
```

真实冒烟报告保存到 Git 忽略的 `evals/gemini-live-latest.json`，与离线/冻结验收报告分开。`operational_success` 只表示得到了通过结构与引用检查的回答，不代表语义正确。报告含模型、用量、证据版本和生成延迟；未返回的 token 数是 `null`，不是零；不估算账单。

网页使用：在设置环境变量的同一终端重新启动服务，然后刷新网页。

```powershell
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --log-config logging.json
```

界面显示「已配置，连接未验证」后，手动将「回答方式」切为 Gemini，再提交问题。页面加载、查看配置、健康检查和点击工作场景不会调用模型；示例保留当前回答方式，提交才可能调用。离线方式始终可选。

本地 Demo 没有公共用户认证或全局费用配额；启用密钥的服务应保持绑定 `127.0.0.1`。测试结束后停止服务，清理当前终端配置：

```powershell
Remove-Item Env:GEMINI_API_KEY -ErrorAction SilentlyContinue
$env:ENABLE_GEMINI = '0'
```

## 请求和状态

```json
{
  "question": "官方文档中 API 创建工单的必填字段是什么？",
  "task": "documentation",
  "answer_mode": "gemini"
}
```

`answer_mode` 默认 `offline`。需要服务端启用、有效格式的配置、请求显式选择 Gemini，且检索先返回 `answered`，才会调用模型。检索不可答时保留原状态，`generation.status=skipped`。

模型只允许输出 `{status, claims}`；每条声明必须引用已有来源 ID，联合问题必须引用两类证据。程序从声明构造最终答案，URL 不由模型生成。有效引用不等于事实正确，仍需人工核对。模型可以主动返回证据不足。

`generation` 描述生成后端、状态、模型、延迟及供应商报告的 tokens；原有 `mode` 描述检索路线。联合响应 `branches` 记录检索阶段，最终状态还可能因生成失败而改变。

| 场景 | 最终状态 / reason_code |
|---|---|
| 未启用 / 缺密钥 / 配置无效 | `upstream_error` / `llm_not_enabled`、`llm_missing_key`、`llm_invalid_config` |
| 生成完成且通过引用校验 | `answered` / `llm_generated_from_evidence` |
| 模型判断证据不足 | `insufficient_evidence` / `llm_insufficient_evidence` |
| 无效 JSON / 无效引用 / 联合证据不全 | `upstream_error` / `llm_invalid_output`、`llm_invalid_citations`、`llm_incomplete_evidence_coverage` |
| 超时 / 网络 / 限流 / 供应商 5xx | `upstream_error` / `llm_timeout`、`llm_connection_error`、`llm_rate_limited`、`llm_provider_error` |
| 权限 / 模型不可用 / 请求被拒绝 | `upstream_error` / `llm_auth_error`、`llm_model_unavailable`、`llm_request_rejected` |
| 拦截 / 截断 / 非预期响应 | `upstream_error` / `llm_blocked`、`llm_output_truncated`、`llm_invalid_response` |
| 输入 / 响应超限 | `upstream_error` / `llm_input_budget_exceeded`、`llm_response_too_large` |

生成失败清空答案、声明和来源，不伪装为离线成功。`retryable=true` 供用户决定是否手动重试；不自动重试 Gemini。`GET /generation` 只检查本地配置；`GET /health` 只检查文档/代码分支，均不验证模型连接。

## 实现边界

- 使用 [generateContent REST API](https://ai.google.dev/api/generate-content)，固定 Google 官方地址，以 `x-goog-api-key` 请求头鉴权，使用参考接口的 `responseMimeType` / `responseJsonSchema` 字段。真实模型兼容性待验证；不支持 Vertex AI 或 OpenAI 兼容网关。
- 仅发送本次问题、选中的公开证据和边界，不上传整个仓库、原离线答案、历史或环境变量。密钥不传给 MCP；日志不记录问题、请求头、模型原始错误体或密钥。
- 每次最多一个候选、一次模型请求。默认输出上限 1024 tokens，可配置 128～2048；请求 JSON 上限 48,000 字符，响应上限 128,000 字节。字符限制不是精确 token 预算，也不是金额硬上限。
- 网络总截止时间默认 20 秒，可配 1～30 秒。不重定向、不读取系统 HTTP 代理，需能直接访问官方 API。
- 无模型工具循环、向量检索、外部搜索或供应商 file search。File Search MCP 仍独立执行本地代码检索。
- 生成位于检索后，不能修复前置路由遗漏。v0.6.1 两个已知同义问法失败与原验收报告仍保留，没有改成模型成功案例。

作品集准确描述：**“Offline-first support assistant with real MCP retrieval, an optional Gemini synthesis adapter, mocked integration tests and an opt-in live smoke workflow. Live model quality and cost have not yet been evaluated.”**
