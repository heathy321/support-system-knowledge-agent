# 官方文档检索与联合分析 v0.6.1

当前只接入三篇 osTicket v1.17.7 官方文档：

- [API：认证与 HTTP 访问](https://docs.osticket.com/en/v1.17.7/Developer%20Documentation/API%20Docs.html)
- [Tickets：工单创建](https://docs.osticket.com/en/v1.17.7/Developer%20Documentation/API/Tickets.html)
- [API Keys：管理配置](https://docs.osticket.com/en/v1.17.7/Admin/Manage/API%20Keys.html)

2026-10-28（日本时间）采集并审核。原始采集时间使用 UTC，可能显示前一天。选用版本路径而非 latest；版本 URL 仍可能被上游修改，因此保留每页 HTML 的 SHA-256。它不是 Git 提交，也不能证明与代码索引的提交相对应。

## 收录范围

六条人工中文摘要：认证请求头与来源 IP、密钥配置、创建端点、基础必填字段、成功响应、支持的工单操作。摘要并非原文引用，不复制整篇文档。API 概览和管理页对密钥设置描述粒度不同，所以只按各章节陈述要求，不把概览中的泛化描述当成免配置保证。

文档页涉及但本版未整理的内容，例如附件格式、反向代理、自定义字段，不等于已接入。未知主题、指定其他版本、特定 4xx/5xx 根因问题均不套用相邻摘要。主题识别是有限关键词规则，并非语义理解。多意图问题的覆盖检查目前也只是有限规则，不能保证识别任意未覆盖的子问题。

## 查询契约

```json
{"question":"官方文档中 API 创建工单的必填字段是什么？","task":"documentation","product_version":"1.17.7"}
```

`task` 支持 auto / documentation / code_analysis / combined。自动识别使用共享的同义表达与主题规则；“最少传哪些信息”可识别为字段要求，“API 钥匙”的后台配置可识别为文档操作问题。无法确定方向时返回 `mode: routing` / `needs_clarification` / `ambiguous_intent`，不调用任一检索后端。明确指定 task 时按该模式执行。纯文档模式同时填代码路径会追问。产品版本字段只约束文档适用范围，不选择代码提交。省略版本时按所收录的 v1.17.7 文档回答，并显示边界。

联合示例：`官方文档的认证请求头是什么？并定位 requireApiKey 函数`。两路独立检索，输出 `branches` 和版本警告。只有两路都 answered 才返回合并答案；任一失败时清空整体答案、claims 和 sources，保留分支状态。总体失败优先级为 upstream_error、needs_clarification、insufficient_evidence。不会声称代码验证了文档、文档证明了根因，或两个版本已对齐。

文档工具是本地 `DocumentationRetriever`，并未伪装为 MCP 调用。代码分析器继续通过真实 File Search MCP。`/documentation` 报告文档库状态；`/health` 独立报告两路 readiness。语料损坏返回 upstream_error，而非“未找到”。

## 来源与维护

`knowledge/osticket-docs.json` 是运行时唯一文档语料，包含页面元数据和摘要。`osticket-doc-sources.json` 是采集清单；二者的来源元数据在发布时应一致。原始页面留在被 Git 忽略的 `data/docs-snapshots/`，不参与运行时检索。

更新步骤：访问并审核明确版本的官方页面；重新采集并计算哈希；按实际章节修订摘要、reviewed_at 和 corpus_version；同步采集清单；运行测试和开发评测。不要仅改日期而不复核内容。换文档版本时需要同时更新来源白名单与版本边界，不能默默覆盖当前版本。运行时读取小语料并计算整体哈希，不访问网络。

新增版本或部署对应关系需要额外证据；当前永远报告 `code_version_relation: unverified`。不推断固定提交属于哪一个发布版本。

## 验证和已知限制

107 项测试通过。18 条开发回归在 local 与 mcp_stdio 后端均通过；原两条失败问题已归入开发集。同一组 18 条问题修复前为 16/18，修复后为 18/18。

v0.6 原始验收首轮 6/8 的报告没有修改。v0.6.1 在实现前另冻结 12 条新验收题，首次通过 10 条；保留 `evals/docs-acceptance-v2-first.json`，未据此继续调规则。新失败为：

- “建单之前，至少要提交哪些资料？”虽然识别到字段意图，但“建单”未通过文档领域检查，返回证据不足。
- “API 最低需要哪些输入才能建单？”未覆盖该表达结构，返回检索方向追问。

两种失败都没有返回无关的代码答案，但仍属于未能回答本可回答问题的失败。可手动选择文档模式，并使用“必填字段”等已支持的主题词。规则识别仍不是任意语义理解。旧、新验收集不同，不应直接比较准确率；详见 [意图验证记录](intent-validation.md)。

验收集由同一开发者/助手编写，不能称为独立或盲测基准。引用逐字匹配摘要只验证引用完整性，不衡量摘要与官方页面的语义蕴含关系。

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m evals.run_support --suite dev --backend local
.\.venv\Scripts\python.exe -m evals.run_support --suite dev --backend mcp_stdio
```

`--suite acceptance` 和 `--suite acceptance_v2` 各自只用于首次运行；已有该组首轮报告时脚本拒绝覆盖。历史代码分析基线继续保留用于对照。
