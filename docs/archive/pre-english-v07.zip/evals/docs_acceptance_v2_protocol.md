# Acceptance v2 protocol

Frozen before v0.6.1 implementation on 2026-10-28 (Asia/Tokyo). Same author as implementation, not independent or blind. Preserve the first result; do not tune on it. Earlier acceptance failures are now development cases, while the original 6/8 report remains unchanged.

New cases SHA-256: `51f797bdfda6d4fa29fa31f9bf3a697beec01e00d116e9a2f86eff7022957b54`

Original 6/8 report SHA-256: `2690df7961db480333fee5931ee1e637d224b5105efcdb25c71778a6d2137953`
