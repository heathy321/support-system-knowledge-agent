# Acceptance protocol

Authored and frozen before implementing the document router on 2026-10-28. Same developer/assistant authored both cases and implementation; this is not an independent or blind benchmark. Do not tune routing to these cases after the first run. Preserve the first-run report and failed case IDs; future tuning must reclassify these as development cases and create new acceptance cases.

Cases SHA-256: `d7d544d2b5f4f5d465e6ed6da95648fc6d4bc77de2eae81dca887f83df06d3b4`
